
public class AssignVariables {
    public static void main(String[] args) {
        boolean someBoolean = false;
        String name = "Palo Alto, CA";
        short num = 32767;
        int bigNum = 2000000000;
        byte smallNum = 127;
        char someChar = 'c';
        long longNum = 919827112351L;
        float floatingPoint = 0.5f;
        double doubleNum = 0.1234567891011;
        //short test = 32768;

        System.out.println(someBoolean);
        System.out.println(name);
        System.out.println(num);
        System.out.println(bigNum);
        System.out.println(smallNum);
        System.out.println(someChar);
        System.out.println(longNum);
        System.out.println(floatingPoint);
        System.out.println(doubleNum);
    }
}
